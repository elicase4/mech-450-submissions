///////////////////////////////////////
// COMP/ELEC/MECH 450/550
// Project 3
// Authors: FILL ME OUT!!
//////////////////////////////////////

#ifndef RANDOM_TREE_H
#define RANDOM_TREE_H

namespace ompl
{
    namespace geometric
    {
        // TODO: Implement RTP as described

        // class RTP : public base::Planner
        // {
        // };

    }  // namespace geometric
}  // namespace ompl

#endif
